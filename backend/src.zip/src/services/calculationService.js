const toNumber = (value, fallback = 0) => {
  if (value === undefined || value === null || value === "") return fallback;

  const parsed = Number(value);
  return Number.isNaN(parsed) ? fallback : parsed;
};

const normalizeTransactionType = (value) => {
  const raw = String(value || "").toLowerCase();

  if (raw === "buy" || raw === "beli") return "Beli";
  if (raw === "sell" || raw === "jual") return "Jual";

  return value;
};

const isBuyType = (type) => {
  return ["beli", "buy"].includes(String(type).toLowerCase());
};

const isSellType = (type) => {
  return ["jual", "sell"].includes(String(type).toLowerCase());
};

const summarizeTransactions = (transactions = [], currentPrice = 0) => {
  let totalBuyQuantity = 0;
  let totalSellQuantity = 0;
  let totalBuyCost = 0;

  for (const trx of transactions) {
    if (isBuyType(trx.transactionType)) {
      totalBuyQuantity += trx.quantity;
      totalBuyCost += trx.quantity * trx.pricePerUnit + trx.fee;
    }

    if (isSellType(trx.transactionType)) {
      totalSellQuantity += trx.quantity;
    }
  }

  const totalQuantity = totalBuyQuantity - totalSellQuantity;
  const averageBuyPrice =
    totalBuyQuantity > 0 ? totalBuyCost / totalBuyQuantity : 0;
  const costBasis = totalQuantity > 0 ? averageBuyPrice * totalQuantity : 0;
  const currentValue = totalQuantity > 0 ? totalQuantity * currentPrice : 0;
  const profitLoss = currentValue - costBasis;

  return {
    totalQuantity,
    totalBuyQuantity,
    totalSellQuantity,
    averageBuyPrice,
    costBasis,
    currentValue,
    profitLoss,
  };
};

const formatAsset = (asset) => {
  const summary = summarizeTransactions(asset.transactions || [], asset.currentPrice);

  return {
    id: asset.id,
    category_id: asset.categoryId,
    category_name: asset.category?.categoryName ?? null,
    asset_name: asset.assetName,
    asset_code: asset.assetCode,
    asset_type: asset.assetType,
    platform: asset.platform,
    risk_level: asset.riskLevel,
    current_price: asset.currentPrice,
    description: asset.description,
    created_at: asset.createdAt,
    updated_at: asset.updatedAt,
    total_quantity: summary.totalQuantity,
    total_buy_quantity: summary.totalBuyQuantity,
    total_sell_quantity: summary.totalSellQuantity,
    average_buy_price: summary.averageBuyPrice,
    cost_basis: summary.costBasis,
    current_value: summary.currentValue,
    profit_loss: summary.profitLoss,
  };
};

const formatTransaction = (transaction) => ({
  id: transaction.id,
  asset_id: transaction.assetId,
  asset_name: transaction.asset?.assetName ?? null,
  asset_code: transaction.asset?.assetCode ?? null,
  transaction_type: transaction.transactionType,
  quantity: transaction.quantity,
  price_per_unit: transaction.pricePerUnit,
  fee: transaction.fee,
  transaction_date: transaction.transactionDate,
  notes: transaction.notes,
  created_at: transaction.createdAt,
});

const formatDashboardPerformance = (asset) => {
  const summary = summarizeTransactions(asset.transactions || [], asset.currentPrice);

  return {
    asset_name: asset.assetName,
    asset_code: asset.assetCode,
    current_price: asset.currentPrice,
    remaining_quantity: summary.totalQuantity,
    average_buy_price: summary.averageBuyPrice,
    current_value: summary.currentValue,
    profit_loss: summary.profitLoss,
  };
};

export {
  toNumber,
  normalizeTransactionType,
  isBuyType,
  isSellType,
  summarizeTransactions,
  formatAsset,
  formatTransaction,
  formatDashboardPerformance,
};