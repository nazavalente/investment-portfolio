import prisma from "../config/db.js";
import {
  formatDashboardPerformance,
  summarizeTransactions,
} from "./calculationService.js";

export const getDashboardSummaryData = async (userId) => {
  const assets = await prisma.asset.findMany({
    where: { userId },
    include: { transactions: true },
  });

  const totalTargets = await prisma.financialTarget.count({
    where: { userId },
  });

  let totalPortfolio = 0;
  let totalProfitLoss = 0;

  for (const asset of assets) {
    const summary = summarizeTransactions(asset.transactions, asset.currentPrice);
    totalPortfolio += summary.currentValue;
    totalProfitLoss += summary.profitLoss;
  }

  return {
    totalPortfolio,
    totalProfitLoss,
    totalAssets: assets.length,
    totalTargets,
  };
};

export const getPortfolioAllocationData = async (userId) => {
  const assets = await prisma.asset.findMany({
    where: { userId },
    include: { transactions: true },
  });

  const grouped = {};

  for (const asset of assets) {
    const summary = summarizeTransactions(asset.transactions, asset.currentPrice);
    const key = asset.assetType || "Lainnya";

    if (!grouped[key]) {
      grouped[key] = 0;
    }

    grouped[key] += summary.currentValue;
  }

  return Object.entries(grouped).map(([name, value]) => ({
    name,
    value,
  }));
};

export const getPortfolioPerformanceData = async (userId) => {
  const assets = await prisma.asset.findMany({
    where: { userId },
    include: { transactions: true },
  });

  return assets.map(formatDashboardPerformance);
};

export const getProfitLossSummaryData = async (userId) => {
  const assets = await prisma.asset.findMany({
    where: { userId },
    include: { transactions: true },
  });

  let totalProfit = 0;
  let totalLoss = 0;

  for (const asset of assets) {
    const summary = summarizeTransactions(asset.transactions, asset.currentPrice);

    if (summary.profitLoss > 0) {
      totalProfit += summary.profitLoss;
    } else if (summary.profitLoss < 0) {
      totalLoss += Math.abs(summary.profitLoss);
    }
  }

  return {
    totalProfit,
    totalLoss,
    netProfitLoss: totalProfit - totalLoss,
  };
};